# Time & Pay Calculator

This app totals hours, calculates gross and net pay, and tracks history. See README for usage instructions.